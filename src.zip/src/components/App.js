import React, { useState } from 'react';
import LlistatTasques from './LlistatTasques';
import FormulariTasques from './FormulariTasques';

function App() {
  const [tasques, setTasques] = useState([]);

  const afegirTasca = tascaNova => {
    const tasquesActuals = [...tasques, tascaNova];
    console.log("Tasques actuals: ", tasquesActuals);
    setTasques(tasquesActuals);
  };

  const eliminarTasca = id => {
    console.log("Eliminando tarea con ID: ", id);
    const tasquesRestants = tasques.filter((tasca, index) => index !== id);
    console.log("Tasques restants: ", tasquesRestants);
    setTasques(tasquesRestants);
  };

  const completarTasca = id => {
    const tasquesActuals = tasques.map((tasca, index) => {
      if (index === id) {
        return {
          ...tasca,
          completada: !tasca.completada
        };
      } else {
        return tasca;
      }
    });
    setTasques(tasquesActuals);
  };

  return (
    <div className="app">
      <h1>Llista de tasques</h1>
      <FormulariTasques onSubmit={afegirTasca} />
      <LlistatTasques
        tasques={tasques}
        completarTasca={completarTasca}
        eliminarTasca={eliminarTasca}
      />
    </div>
  );
}

export default App;