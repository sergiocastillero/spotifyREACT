import React from 'react';
import { FaTrashAlt } from 'react-icons/fa';

function Tasca(props) {
  const { id, text, completada, eliminarTasca, completarTasca } = props;

  const handleCompletadaClick = () => {
    console.log("mod")
    completarTasca(id);
  };

  const handleEliminarClick = () => {
    console.log("el")
    eliminarTasca(id);
  };

  return (
    <div
      className={completada ? 'tasca tascaCompletada' : 'tasca'}
      
    >
      <span onClick={handleCompletadaClick}>{text}</span>
      <button onClick={handleEliminarClick}>
        <FaTrashAlt />
      </button>
    </div>
  );
}

export default Tasca;