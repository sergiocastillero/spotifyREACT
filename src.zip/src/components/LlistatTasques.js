import React from 'react';
import Tasca from './Tasca';

function LlistatTasques(props) {
  const { tasques, eliminarTasca, completarTasca } = props;

  return (
    <div>
      {tasques.map((tasca, index) => (
        <Tasca
          key={index}
          id={index}
          text={tasca.titol}
          completada={tasca.completada}
          eliminarTasca={eliminarTasca}
          completarTasca={completarTasca}
        />
      ))}
    </div>
  );
}

export default LlistatTasques;