import React, { useState } from 'react';

function FormulariTasques(props) {
  const { onSubmit } = props;
  const [textTasca, setTextTasca] = useState('');

  const canviTextTasca = e => {
    setTextTasca(e.target.value);
  };

  const enviarForm = e => {
    e.preventDefault();
    const tascaNova = {
      titol: textTasca,
      completada: false,
    };
    onSubmit(tascaNova);
    setTextTasca('');
  };

  return (
    <form onSubmit={enviarForm}>
      <input type="text" value={textTasca} onChange={canviTextTasca} />
      <button type="submit">Afegir tasca</button>
    </form>
  );
}

export default FormulariTasques;
